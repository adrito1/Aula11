import java.util.Arrays;

public class BuscaBinariaView {
    public void mostrarResultado(int elemento, int resultado) {
        if (resultado == -1) {
            System.out.println("Elemento " + elemento + " não encontrado.");
        } else {
            System.out.println("Elemento " + elemento + " encontrado no índice " + resultado + ".");
        }
    }

    public void mostrarArrayOrdenado(int[] array) {
        System.out.println("Array ordenado: " + Arrays.toString(array));
    }
}
