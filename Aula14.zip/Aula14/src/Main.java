import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] array = {54, 26, 93, 17, 77, 31, 44, 55, 20, 65};

        BuscaBinariaController controller = new BuscaBinariaController();
        BuscaBinariaView view = new BuscaBinariaView();

        // Ordenando o array
        Arrays.sort(array);
        view.mostrarArrayOrdenado(array);

        int numeroParaEncontrar = 31;
        int resultado = controller.buscarElemento(array, numeroParaEncontrar);

        view.mostrarResultado(numeroParaEncontrar, resultado);
    }
}
