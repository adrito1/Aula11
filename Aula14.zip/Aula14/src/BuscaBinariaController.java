public class BuscaBinariaController {
    private BuscaBinaria model;

    public BuscaBinariaController() {
        this.model = new BuscaBinaria();
    }

    public int buscarElemento(int[] array, int elemento) {
        return model.buscaBinaria(array, elemento);
    }
}
